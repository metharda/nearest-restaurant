import Map from '@/components/map';
export default function Home() {
  return (
    <main className="relative h-screen w-full">
      <Map/>
    </main>
  );
}
